(function(){
    let screen = document.querySelector('.screen');
    let buttons = document.querySelectorAll('.btn');
    let clear = document.querySelector('.btn-clear');
    let equal = document.querySelector('.btn-equal');
    

    buttons.forEach(function(button){
        button.addEventListener('click',function(e){
            let value = e.target.innerText;
            console.log(value);
            if(value == "sin"){
                screen.value=Math.sin(screen.value);
            }
            else if(value=="cos"){
                screen.value=Math.cos(screen.value);
            }
            else if(value=="tan"){
                screen.value=Math.tan(screen.value);
            }
            else if(value=="pow"){
                screen.value=Math.pow(screen.value,2);
            }            
            else if(value=="round"){
                screen.value=Math.round(screen.value);
            }
            else if(value=="log"){
                screen.value=Math.log(screen.value);
            }
            else if(value=="log10"){
                screen.value=Math.log10(screen.value);
            }
            else if(value=="abs"){
                screen.value=Math.abs(screen.value);
            }
            else if(value=="n!"){
                if(screen.value == 0){
                    screen.value = 0;
                }
                else if(screen.value == 1){
                    screen.value = 1;
                }
                else{
                    let fact = 1;
                    for(let i = 1; i <= screen.value; i++){
                        fact *= i;
                    }
                    screen.value = fact;
                }
            }
            else{
                screen.value +=value;
            }
            
        })
    });
    
    equal.addEventListener('click', function(e){
        if(screen.value === ''){
            screen.value = "";
        }else{
            let answer = eval(screen.value);
            screen.value = answer;
        }
    })
    clear.addEventListener('click', function(e){
        screen.value = "";
    })
    
    

})();
