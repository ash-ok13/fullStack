document.getElementById('billBtn').onclick = function(){
 
  const fixed_cost=50.0
  const new_subsidy=250.0
  let net_amt=0.0
  consumedUnits = parseFloat(document.getElementById('units').value);
  if(consumedUnits < 0){
    alert("Invalid units entered");
  }
  if (consumedUnits <= 100) {
    totalCost = 0;
  } else if (consumedUnits <= 200) {
    totalCost = 100 + ((consumedUnits - 100) * 3.75);
  } else if (consumedUnits <= 400) {
    totalCost = 250 + ((consumedUnits - 200) * 4);
  } else if (consumedUnits <= 600) {
    totalCost = 300 + ((consumedUnits - 400) * 4.25);
  } else {
    totalCost = 400 + ((consumedUnits - 600) * 5);
  }
  
  
  net_amt=totalCost+fixed_cost-new_subsidy;
  document.getElementById('conUnits').innerText = consumedUnits.toFixed(2);
  document.getElementById('totalChg').innerText = totalCost.toFixed(2);
  document.getElementById('currentChg').innerText = totalCost.toFixed(2);
  document.getElementById('fc').innerText = fixed_cost.toFixed(2);
  document.getElementById('subFc').innerText = 0.0;
  document.getElementById('newSub').innerText = new_subsidy.toFixed(2);
  document.getElementById('netAmt').innerText = net_amt.toFixed(2);


}




