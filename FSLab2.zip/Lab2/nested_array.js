const parts = [
    ['Monitors', 'LCD Screens', 'LED Screens', 'Vibrant Colors'],
    ['Motherboards', 'Fast'],
    ['Chips', 'i9', 'i7', 'i5', 'i3', 'Core2Duo', 'Pentium', 'Very Fast'],
    ['Hard Drives', '2TB', '1TB', '100-500 GB', 'Fast Reading'],
    ['DVD-ROMs', 'Burn CDs', 'Burn DVDs'],
    ['Cases', 'ATX', 'AT', 'Mini', 'Other Sizes', 'Choice of Colors.'],
    ['Power Supplies', 'we can get one for any computer!']
  ];
  
  let output = '';
  for (let i = 0; i < parts.length; i++) {
    output += parts[i][0] + ': ';
    for (let j = 1; j < parts[i].length; j++) {
      output += parts[i][j] + ', ';
    }
    output = output.slice(0, -2); // Remove the last comma and space
    output += '\n';
  }
  console.log(output);
  document.getElementById('computer').innerText = output;
  
  