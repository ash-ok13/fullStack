let counter = 1;

imgChange.onclick = function(){
    if(counter == 0){
        document.getElementById("imgChange").src = "./images/black.png";
        counter++;
    }
    else if(counter == 1){
        document.getElementById("imgChange").src = "./images/blue.png";
        counter++;
    }
    else if(counter == 2){
        document.getElementById("imgChange").src = "./images/green.png";
        counter++;
    }
    else if(counter == 3){
        document.getElementById("imgChange").src = "./images/orange.png";
        counter++;
    }
    else if(counter == 4){
        document.getElementById("imgChange").src = "./images/red.png";
        counter = 0;
    }


};