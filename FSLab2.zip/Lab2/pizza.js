document.getElementById('billPizza').onclick = function(){
    const size = document.getElementById("size").value;
    const deep_pan = document.getElementById("deep_pan");
    const delivery = document.getElementById("delivery");
    let cost = 0;
        if(size == 1){
            cost += 99;
        }
        else if(size == 2){
            cost += 199;
        }
        else if(size == 3){
            cost += 399;
        }
    
    if(deep_pan.checked){
        
        if(deep_pan.value == 1){
            cost += 20;
        }
    }
    
    let toppings = document.querySelectorAll('input[name="toppings"]:checked');
    toppings.forEach(function(topping) {
      var toppingName = topping.value;
      console.log(toppingName);
      if (toppingName === 'mushrooms') {
        cost += 15;
      } else if (toppingName === 'olives') {
        cost += 10;
      } else if (toppingName === 'fingernail') {
        cost += 30;
      } else if (toppingName === 'spicy-beef') {
        cost += 20;
      }
     });
    
    if(delivery.checked){
        if (delivery.value == 1) {
            cost += 25;
          }
    }
     
    
    document.getElementById('result').innerHTML = 'Total Cost : ₹' + cost;
}  