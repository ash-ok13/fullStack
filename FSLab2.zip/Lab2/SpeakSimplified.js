document.getElementById('exclusion').onclick = function(){
    let word = document.getElementById('wrd').value;
    let result = exclusion(word);
    document.getElementById('result').innerHTML = result;
}
document.getElementById('strength').onclick = function(){
    let word = document.getElementById('wrd').value;
    let result = strengthen(word);
    document.getElementById('result').innerHTML = result;
}
document.getElementById('emphasize').onclick = function(){
    let word = document.getElementById('wrd').value;
    let result = emphasize(word);
    document.getElementById('result').innerHTML = result;
}
function exclusion(word){
    return "un" + word;
}
function strengthen(word){
    return "plus" + word;
}
function emphasize(word){
    return "doubleplus" + word;
}