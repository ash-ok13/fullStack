function orderForm(){
    let city = document.getElementById("city").value;
    let maxItems = 0;
    switch (city) {
        case "chennai":
            maxItems = 15;
            break;
        case "coimbatore":
            maxItems = 12;
            break;
        case "madurai":
            maxItems = 12;
            break;
        case "salem":
            maxItems = 8;
            break;
        case "tiruchirappalli":
            maxItems = 6;
            break;
        case "thoothukudi":
            maxItems = 2;
            break;
        default:
            return;
    }

    let orderForm = '<h3>Order Form for ' + city.toUpperCase() + '</h3>';
    for (var i = 1; i <= maxItems; i++) {
        orderForm += '<h5><label for="item' + i + '">Item' + i + ': </label><br><input type="text" id="item' + i + '" name="item' + i + '"><br>';
    }
    document.getElementById("form-container").innerHTML = orderForm;
}
